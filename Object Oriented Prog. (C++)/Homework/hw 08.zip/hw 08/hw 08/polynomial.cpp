//
//  polynomial.cpp
//  hw 08
//
//  Created by Safiullah Hasani on 12/2/18.
//  Copyright © 2018 Safiullah Hasani. All rights reserved.
//

#include "polynomial.hpp"

#include <iostream>
#include <vector>
#include <string>
using namespace std;


void listClear(Node*& headPtr) {
    if (headPtr == nullptr) return;
    Node* next = headPtr->next;
    
    while (next != nullptr) {
        delete headPtr;
        headPtr = next;
        next = next->next;
    }
    delete headPtr;
    headPtr = nullptr;
}


Node* listDuplicate(Node* headPtr) {
    if (headPtr == nullptr) return nullptr;
    Node* result = new Node(headPtr->data);
    Node* last = result;
    Node* p = headPtr->next;
    
    while (p != nullptr) {
        last->next = new Node(p->data);
        p = p->next;
        last = last->next;
    }
    
    return result;
}

int listLength(const Node* headPtr) {
    const Node* p = headPtr;
    int count = 0;
    while (p != nullptr) {
        ++count;
        p = p->next;
    }
    return count;
}

void listAddHead(Node*& headPtr, int data) {
    headPtr = new Node(data, headPtr);
}

Node* listBuild(const vector<int>& vals) {
    Node* result = nullptr;
    for (size_t index = vals.size(); index > 0; --index) {
        listAddHead(result, vals[index-1]);
    }
    return result;
}




Polynomial::Polynomial(const Polynomial& rhs){
    headPoly = listDuplicate(rhs.headPoly);
    degree = listLength(headPoly) - 1;
}

Polynomial& Polynomial::operator=(const Polynomial& rhs){
    listClear(headPoly); // allocate space as needed
    headPoly = listDuplicate(rhs.headPoly); // copying of data
    degree = listLength(headPoly) - 1;
    return *this;
}

Polynomial::~Polynomial(){
    listClear(headPoly);
}

int Polynomial::evaluate(int xVal){
    int output = evalHelp(xVal, headPoly, 0); // uses the recursive helper function
    return output;
}

Polynomial Polynomial::operator+(const Polynomial& rhs){
    vector<int> results; // results will be held in a vector, which creates a new Polynomial
    
    Node* lhsData = headPoly;
    Node* rhsData = rhs.headPoly;
    
    if (listLength(lhsData) == listLength(rhsData)){ // two Poly's are of even degree
        // Both of their linked lists end at the same time
        while (lhsData != nullptr){ // is true when they both end
            results.push_back(lhsData->data + rhsData->data);
            lhsData = lhsData->next;
            rhsData = rhsData->next;
        }
    } else { // they're different lengths
        if(listLength(lhsData) > listLength(rhsData)){ // left side bigger than right
            while (rhsData != nullptr){ // stops adding them together when the short(rhs) ends
                results.push_back(lhsData->data + rhsData->data); // adds the results to a vector
                lhsData = lhsData->next;
                rhsData = rhsData->next;
            }
            while(lhsData != nullptr){ // finishes up adding the one with the higher degree
                results.push_back(lhsData->data);
                lhsData = lhsData->next;
            }
        } else { // right side is bigger than the left
            while (lhsData != nullptr){ // same ss before but rhs is longer
                results.push_back(lhsData->data + rhsData->data);
                lhsData = lhsData->next;
                rhsData = rhsData->next;
            }
            while(rhsData != nullptr){
                results.push_back(rhsData->data);
                rhsData = rhsData->next;
            }
        }
    }
    
    while(results.back() == 0){ // removes any highest-degree 0's
        results.pop_back();
    }
    
    reverse(results.begin(), results.end());
    return Polynomial(results);
}

Polynomial& Polynomial::operator+=(const Polynomial& rhs){
    *this = (*this + rhs);
    return *this;
}

int Polynomial::evalHelp(int xVal, Node*& node, int degree){
    if(node == nullptr){ // outlier case is true when the linked list ends
        return 0;
    } else {
        int output = 1; // output = xVal^degree
        for(int i = 0; i < degree; i++){output *= xVal;}
        return (node->data * output) + evalHelp(xVal, node->next, degree + 1);
        // node->data is the coefficient
        // uses the degree to know how many times to multiply 'output' by iteself
    }
}

ostream& outputHelper(ostream& os, const Node* node, int expo, int limit){
    // expo is the current degree, limit is the highest degree it can reach
    if(expo == limit) { // at the 'base case' of the recursion, with the highest degree item
        if (node->data != 1 && node->data != 0){
            os << node->data << "x^" << expo << " + ";
        } else if (node->data == 1 && expo==1){
            os << "x + ";
        }
        return os;
    }
    
    outputHelper(os, node->next, expo+1, limit); // call on the next element in the linked list, done here to ensure highest degree is written first
    
    if(node->data != 0){
        if (node ->data != 1){
            os << node->data;
        } else if (node->data == 1 && expo==0){
            os << node->data;
        }
        if(expo == 1) { // deals with what degree the items are
            os << "x + ";
        } else if (expo != 0) {
            os << "x^" << expo << " + ";
        }
    }
    //if expo == 0, there doesn't need to be anything added to os, it's the end of the poly
    return os;
}

ostream& operator<<(ostream& os, const Polynomial& poly){
    int limit = poly.degree;
    
    if(limit == 0){ // there's only one element in the polynomial
        os << poly.headPoly->data;
        
    } else { // there's more than one, uses recursive helper function
        outputHelper(os, poly.headPoly, 0, limit); // starts the recursive helper
    }
    
    return os;
}

bool operator==(const Polynomial& lhs, const Polynomial& rhs){
    if(lhs.degree != rhs.degree){
        return false; // different lengths, not equal
    } else {
        Node* currLeft = lhs.headPoly;
        Node* currRight = rhs.headPoly;
        while(currLeft != nullptr){ // two 'walking' pointers to nodes in each poly constantly comparing, return false if not equal.
            if(currLeft->data != currRight->data){
                return false;
            } else {
                currLeft = currLeft->next;
                currRight = currRight->next;
            }
        }
        return true; // succesfully walked through both poly's and didn't fail
    }
}

bool operator!=(const Polynomial& lhs, const Polynomial& rhs){
    return !(lhs == rhs);
}

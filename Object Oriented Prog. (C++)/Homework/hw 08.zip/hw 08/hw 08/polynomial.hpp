//
//  polynomial.hpp
//  hw 08
//
//  Created by Safiullah Hasani on 12/2/18.
//  Copyright © 2018 Safiullah Hasani. All rights reserved.
//

#ifndef polynomial_hpp
#define polynomial_hpp

#include <stdio.h>
#include <iostream>
#include <vector>
#include <string>

using namespace std;
// start of code given to us in class
struct Node {
    Node(int data = 0, Node* next = nullptr) : data(data), next(next) {}
    int data;
    Node* next;
};


void listClear(Node*& headPtr);

Node* listDuplicate(Node* headPtr);

int listLength(const Node* headPtr);

void listAddHead(Node*& headPtr, int data);

Node* listBuild(const vector<int>& vals);

// end of code given to us in class
class Polynomial{
public:
    Polynomial(vector<int> inputVect = {0}) : headPoly(listBuild(inputVect)) {
        // used a copy DELIBERATLY because reverse
        reverse(inputVect.begin(), inputVect.end());
        // coded for lowest degree first (makes addition easier, as well as output)
        // so reverse is needed
        headPoly = listBuild(inputVect);
        degree = listLength(headPoly) - 1; // degree will always be one less than number of elements
    }
    
    Polynomial(const Polynomial& rhs);
    
    Polynomial& operator=(const Polynomial& rhs);
    
    ~Polynomial();
    
    int evaluate(int xVal);
    
    Polynomial operator+(const Polynomial& rhs);
    
    Polynomial& operator+=(const Polynomial& rhs);
    
    friend ostream& operator<<(ostream& os, const Polynomial& poly);
    
    friend bool operator==(const Polynomial& lhs, const Polynomial& rhs);
    
private:
    
    int evalHelp(int xVal, Node*& node, int degree);
    
    Node* headPoly;
    int degree;
    
};

ostream& outputHelper(ostream& os, const Node* node, int expo, int limit);

bool operator!=(const Polynomial& lhs, const Polynomial& rhs);


#endif /* polynomial_hpp */
